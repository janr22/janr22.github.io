<?php
//including the database connection file
include("config.php");

//getting id of the data from url
$car_id = $_GET['car_id'];

//deleting the row from table
$result = mysqli_query($mysqli, "DELETE FROM cars WHERE car_id=$car_id");

//redirecting to the display page (index.php in our case)
header("Location:index.php");
?>