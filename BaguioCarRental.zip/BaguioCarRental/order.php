<?php 
include_once 'dbh.php'
    ?>
    <!doctype html>
    <html>

    <head>
        <title> ORDERS </title>
        <link rel="stylesheet" type="text/css" href="assets/css/style.css"> </head>

    <body>
        <?php
    $sql = "SELECT * FROM `order`;";
    $result = mysqli_query($conn, $sql);
    $resultCheck = mysqli_num_rows($result);

        echo "<table table-border='1' cellpadding='10' display:center;>
        <tr>
        <th>Order Number</th>
        <th>User ID</th>
        <th>User Name</th>
        <th>Plate Number</th>
        <th>Date Borrowed</th>
        <th>Date Returned</th>
        <th>Total Amount</th>
        <th>Payment Status</th>
        <th>Action</th>
        </tr>";

    if ($resultCheck > 0){
        while ($order = mysqli_fetch_assoc($result)){
            echo "<tr>";
            echo "<td>".$order['order_number'];
            echo "<td>".$order['user_id'];
            echo "<td>".$order['username'];
            echo "<td>".$order['plate_number'];
            echo "<td>".$order['date_borrowed'];
            echo "<td>".$order['date_returned'];
            echo "<td>".$order['total_amount'];
            echo "<td>".$order['payment_status'];
        }
    }
?>
    </body>

    </html>