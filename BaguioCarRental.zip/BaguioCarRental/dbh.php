<?php
$dbServername ="localhost";
$dbUserName="root";
$dbPassword="";
$dbname="car_rental";


$conn=mysqli_connect($dbServername,$dbUserName,$dbPassword,$dbname);