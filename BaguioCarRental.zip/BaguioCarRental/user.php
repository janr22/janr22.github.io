<?php 
include_once 'dbh.php'
    ?>
    <!doctype html>
    <html>

    <head>
        <title> ORDERS </title>
        <link rel="stylesheet" type="text/css" href="assets/css/style.css"> </head>

    <body>
        <?php
    $sql = "SELECT * FROM users;";

    $result = mysqli_query($conn, $sql);
    $resultCheck = mysqli_num_rows($result);

        echo "<table border='1' cellpadding='10' display:center;>
        <tr>
        <th>User ID </th>
        <th>User Name</th>
        <th>User Email</th>
        <th>Password</th>
        <th>Contact Number</th>
        <th>Complete Address</th>
        <th>Type of user</th>
        </tr>";

    if ($resultCheck > 0){
        while ($users = mysqli_fetch_assoc($result)){
            echo "<tr>";
            echo "<td>".$users['id'];
            echo "<td>".$users['username'];
            echo "<td>".$users['useremail'];
            echo "<td>".$users['password'];
            echo "<td>".$users['contactNumber'];
            echo "<td>".$users['complet address'];
            echo "<td>".$users['type of user'];
    
            
            echo "</tr>";            
            
        }
    }

    ?>
    </body>

    </html>