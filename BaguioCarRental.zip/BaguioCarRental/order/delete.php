<?php
//including the database connection file
include("config.php");

//getting id of the data from url
$order_number = $_GET['order_number'];

//deleting the row from table
$result = mysqli_query($mysqli, "DELETE FROM orders WHERE order_number=$order_number");

//redirecting to the display page (index.php in our case)
header("Location:index.php");
?>