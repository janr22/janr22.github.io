<?php
session_start(); 

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: index.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location:logout.php");
	}
// including the database connection file
include_once("config.php");

if(isset($_POST['update']))
{	
	$payment_id = mysqli_real_escape_string($mysqli, $_POST['payment_id']);
	$user_id = mysqli_real_escape_string($mysqli, $_POST['user_id']);
	$total_amount = mysqli_real_escape_string($mysqli, $_POST['total_amount']);
	$order_number = mysqli_real_escape_string($mysqli, $_POST['order_number']);

// checking empty fields
	if(empty($user_id) ||  empty($total_amount) || empty($order_number)) {	
		
     

        if(empty($user_id)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}

        if(empty($total_amount)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
		if(empty($order_number)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
			
	} else {	
		//updating the table
		$result = mysqli_query($mysqli, "UPDATE payment SET user_id='$user_id',total_amount='$total_amount',order_number='$order_number' WHERE payment_id =$payment_id");

		//redirectig to the display page. In our case, it is index.php
		header("Location:index.php");
	}
}
?>
    <?php

//getting order_number from url
$payment_id = $_GET['payment_id'];

//selecting data associated with this particular order_number

$result = mysqli_query($mysqli, "SELECT * FROM payment WHERE payment_id=$payment_id");

while($res = mysqli_fetch_assoc($result))

{
    $user_id = $res['user_id'];
    $total_amount = $res['total_amount'];
    $order_number = $res['order_number'];
     
}


?>
        <html>

        <head>
            <title>Payment of the Orders</title>
            <script src="../https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
            <script src="../assets/js/chart-master/Chart.js"></script>
            <!-- Bootstrap core CSS -->
            <link href="../assets/css/bootstrap.css" rel="stylesheet">
            <!--external css-->
            <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
            <!-- Custom styles for this template -->
            <link href="../assets/css/style.css" rel="stylesheet">
            <link href="../assets/css/style-responsive.css" rel="stylesheet">
            <link href="../assets/css/table-responsive.css" rel="stylesheet">
            <link href="../https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css" rel="stylesheet" />
            <script src="../https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
            <!-- Bootstrap core CSS -->
            <!-- Bootstrap core CSS -->
            <link href="../assets/css/bootstrap.css" rel="stylesheet">
            <!--external css-->
            <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
            <link rel="../stylesheet" type="text/css" href="../assets/css/zabuto_calendar.css">
            <link rel="../stylesheet" type="text/css" href="../assets/js/gritter/css/jquery.gritter.css" />
            <link rel="../stylesheet" type="text/css" href="../assets/lineicons/style.css">
            <!-- Custom styles for this template -->
            <link href="../assets/css/style.css" rel="stylesheet">
            <link href="../assets/css/style-responsive.css" rel="stylesheet"> </head>

        <body>
            <section id="container">
                <header class="header black-bg">
                    <div class="sidebar-toggle-box">
                        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
                    </div>
                    <!--logo start--><a href="../index.html" class="logo"><b>BAGUIO CAR RENTAL</b></a>
                    <!--logo end-->
                    <div class="nav notify-row" id="top_menu">
                        <!--  notification start -->
                        <ul class="nav top-menu">
                            <!-- inbox dropdown end -->
                        </ul>
                        <!--  notification end -->
                    </div>
                    <div class="top-menu">
                        <ul class="nav pull-right top-menu">
                            <li><a class="logout" href="../logout.php">Logout</a></li>
                        </ul>
                    </div>
                </header>
                <aside>
                    <div id="sidebar" class="nav-collapse ">
                        <!-- sidebar menu start-->
                        <ul class="sidebar-menu" id="nav-accordion">
                            <p class="centered">
                                <a href="profile.html"><img src="../assets/img/ui-sam.jpg" class="img-circle" width="60"></a>
                            </p>
                            <h5 class="centered">ADMIN</h5>
                            <li class="mt">
                                <a href="javascript:;"> <i class="fa fa-desktop"></i> <span>HOME</span> </a>
                            </li>
                            <li class="sub-menu">
                                <a href="javascript:;"> <i class="fa fa-cogs"></i> <span>Registered User</span> </a>
                            </li>
                            <li class="sub-menu">
                                <a href="javascript:;"> <i class="fa fa-cogs"></i> <span>Registered Company </span> </a>
                            </li>
                            <li class="sub-menu">
                                <a href=""> <i class="fa fa-cogs"></i> <span>Vehicle Management</span> </a>
                            </li>
                            <li class="sub-menu">
                                <a href="../order/index.php"> <i class="fa fa-cogs"></i> <span>Order</span> </a>
                            </li>
                            <li class="sub-menu">
                                <a href="../payment/index.php"> <i class="fa fa-cogs"></i> <span>Payment</span> </a>
                            </li>
                            <li class="sub-menu">
                                <a href=""> <i class="fa fa-cogs"></i> <span>Sales</span> </a>
                            </li>
                        </ul>
                        <!-- sidebar menu end-->
                    </div>
                </aside>
             <section id="main-content">
    <section class="wrapper">
        <div class="row mt">
            <div class="col-lg-12">
                <div class="content-panel">
                    <h4><i class="fa fa-angle-right"></i> Payment of the orders</h4>
                    <section id="unseen">
                        <form name="form1" method="post" action="edit.php">
                            <table class="table table-bordered table-striped table-condensed">
                                <tr>
                                    <td>Payment ID</td>
                                    <td>
                                        <input type="text" name="payment_id" value="<?php echo $payment_id;?>"> </td>
                                </tr>
                                <tr>
                                    <td>User ID</td>
                                    <td>
                                        <input type="text" name="user_id" value="<?php echo $user_id;?>"> </td>
                                </tr>
                                <tr>
                                    <td>Total Amount</td>
                                    <td>
                                        <input type="text" name="total_amount" value="<?php echo $total_amount;?>"> </td>
                                </tr>
                                <tr>
                                    <td>Order Number</td>
                                    <td>
                                        <input type="text" name="order_number" value="<?php echo $order_number;?>"> </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="hidden" name="payment_id" value="<?php echo $_GET['payment_id'];?>"> </td>
                                    <td>
                                        <input type="submit" name="update" value="Update"> </td>
                                </tr>
                            </table>
                        </form>
                    </section>
                </div>
            </div>
        </div>
    </section>
</section>
            </section>
            <footer class="site-footer">
                <div class="text-center"> ADMIN
                    <a href="" class="go-top"> <i class="fa fa-angle-up"></i> </a>
                </div>
            </footer>
            <!--footer end-->
            <!-- js placed at the end of the document so the pages load faster -->
            <script src="../assets/js/jquery.js"></script>
            <script src="../assets/js/bootstrap.min.js"></script>
            <script class="include" type="text/javascript" src="../assets/js/jquery.dcjqaccordion.2.7.js"></script>
            <script src="../assets/js/jquery.scrollTo.min.js"></script>
            <script src="../assets/js/jquery.nicescroll.js" type="text/javascript"></script>
            <!--common script for all pages-->
            <script src="../assets/js/common-scripts.js"></script>
            <!--script for this page-->
            <!-- js placed at the end of the document so the pages load faster -->
            <script src="../assets/js/jquery.js"></script>
            <script src="../assets/js/jquery-1.8.3.min.js"></script>
            <script src="../assets/js/bootstrap.min.js"></script>
            <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
            <script src="../assets/js/jquery.scrollTo.min.js"></script>
            <script src="../assets/js/jquery.nicescroll.js" type="text/javascript"></script>
            <script src="assets/js/jquery.sparkline.js"></script>
            <!--common script for all pages-->
            <script src="../assets/js/common-scripts.js"></script>
            <script type="../text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
            <script type="../text/javascript" src="assets/js/gritter-conf.js"></script>
            <!--script for this page-->
            <script src="../assets/js/sparkline-chart.js"></script>
            <script src="../assets/js/zabuto_calendar.js"></script>
            <script type="text/javascript">
                $(document).ready(function () {
                    var unique_id = $.gritter.add({
                        // (string | mandatory) the heading of the notification
                        title: 'Welcome ADMIN!', // (string | mandatory) the text inside the notification
                        text: '</a>.', // (string | optional) the image to display on the left
                        image: 'assets/img/ui-sam.jpg', // (bool | optional) if you want it to fade out on its own or just sit there
                        sticky: true, // (int | optional) the time you want it to be alive for before fading out
                        time: '', // (string | optional) the class name you want to apply to that specific message
                        class_name: 'my-sticky-class'
                    });
                    return false;
                });
            </script>
            <script type="application/javascript">
                $(document).ready(function () {
                    $("#date-popover").popover({
                        html: true
                        , trigger: "manual"
                    });
                    $("#date-popover").hide();
                    $("#date-popover").click(function (e) {
                        $(this).hide();
                    });
                    $("#my-calendar").zabuto_calendar({
                        action: function () {
                            return myDateFunction(this.id, false);
                        }
                        , action_nav: function () {
                            return myNavFunction(this.id);
                        }
                        , ajax: {
                            url: "show_data.php?action=1"
                            , modal: true
                        }
                        , legend: [
                            {
                                type: "text"
                                , label: "Special event"
                                , badge: "00"
                        }
                        , {
                                type: "block"
                                , label: "Regular event"
                            , }
                ]
                    });
                });

                function myNavFunction(id) {
                    $("#date-popover").hide();
                    var nav = $("#" + id).data("navigation");
                    var to = $("#" + id).data("to");
                    console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
                }
            </script>
        </body>

        </html>