<?php
//including the database connection file
include("config.php");

//getting id of the data from url
$payment_id = $_GET['payment_id'];

//deleting the row from table
$result = mysqli_query($mysqli, "DELETE FROM payment WHERE payment_id=$payment_id");

//redirecting to the display page (index.php in our case)
header("Location:index.php");
?>